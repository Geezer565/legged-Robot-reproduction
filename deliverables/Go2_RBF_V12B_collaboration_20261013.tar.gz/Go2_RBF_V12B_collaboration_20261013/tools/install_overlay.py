#!/usr/bin/env python3
"""只读预检为默认行为；只有 --apply 才真正复制 overlay 到 repo。"""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
import shutil

def git(repo, *args):
    p=subprocess.run(['git','-C',str(repo),*args], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError('git '+ ' '.join(args)+': '+p.stderr.strip())
    return p.stdout.strip()

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description='审查并可选择安装 Go2 RBF/ETH 集成 overlay（不会 git commit/push）')
    ap.add_argument('--repo',type=Path,required=True, help='队友仓库根目录')
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--check',action='store_true',help='仅检查，不修改任何文件')
    g.add_argument('--apply',action='store_true',help='显式允许覆盖文件，仅适用于干净的基线克隆')
    a=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    data=json.loads((root/'manifest_release.json').read_text(encoding='utf-8'))
    repo=a.repo.expanduser().resolve()
    if git(repo, 'rev-parse','--show-toplevel')!=str(repo):
        raise RuntimeError('必须指定仓库根目录')
    if git(repo,'rev-parse','HEAD')!=data['base_commit']:
        raise RuntimeError('HEAD 不是指定 GitHub 基础提交。请在单独的干净克隆中检出 7884111 后再试。')
    conflicts=[]; unchanged=[]; install=[]
    for entry in data['overlay_files']:
        rel=entry['path']; file=root/'overlay'/rel; destination=repo/rel
        if not file.is_file() or sha(file)!=entry['sha256']:
            conflicts.append(rel+' （发布包源文件不存在/校验失败）');continue
        if destination.is_symlink():
            conflicts.append(rel+' （目标是符号链接）');continue
        if entry['kind']=='tracked_modified':
            basehash=git(repo,'rev-parse',data['base_commit']+':'+rel)
            if not destination.is_file() or git(repo,'hash-object',str(destination))!=basehash:
                conflicts.append(rel+' （基线已有变化；拒绝覆盖）');continue
        elif destination.exists() and (not destination.is_file() or sha(destination)!=entry['sha256']):
            conflicts.append(rel+' （新文件路径已有其他内容；拒绝覆盖）');continue
        if destination.exists() and sha(destination)==entry['sha256']:
            unchanged.append(rel)
        else:
            install.append(entry)
    print(f'版本基线 OK；需写入 {len(install)} 个文件；已相同 {len(unchanged)} 个；冲突 {len(conflicts)} 个')
    if conflicts:
        for c in conflicts:print('[冲突] '+c)
        raise SystemExit(2)
    if a.check:
        print('[安全检查通过] 这是只读模式，仓库未改变。')
        return
    # 上面预检全部通过，才写入。写入前保存原 tracked 的拷贝，以便出错人工恢复。
    backups=repo/'.rbf_sync_backups'
    if install:
        backups.mkdir(exist_ok=True)
    for entry in install:
        rel=entry['path'];target=repo/rel; origin=root/'overlay'/rel
        if target.is_file():
            backup=backups/rel;backup.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(target, backup)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(origin,target)
        target.chmod(entry['mode'])
    print('[已应用] 修改已写入仓库，但未 git add/commit/push；原 tracked 文件备份存于 .rbf_sync_backups/')
    print('先用 git diff / git status 复核，再自行提交。不要提交 .rbf_sync_backups/。')

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('[失败]',e,file=sys.stderr);sys.exit(1)
