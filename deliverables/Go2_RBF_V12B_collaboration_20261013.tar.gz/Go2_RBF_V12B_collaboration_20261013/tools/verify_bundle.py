#!/usr/bin/env python3
"""离线静态核验：不导入 ROS，不联网、不写工作区。"""
from pathlib import Path
import hashlib,json,re,ast,sys
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'manifest_release.json').read_text(encoding='utf-8'))
assert len(m['overlay_files'])==43
for e in m['overlay_files']:
    p=root/'overlay'/e['path']
    assert p.is_file(),str(p)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256'],str(p)
    if p.suffix=='.py':
        ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
configs=['myrbf_v11_equivalent_wrench_go2.yaml']
configs_root=root/'overlay'/'GO2/code/legged_robot_workspace'
paths=[configs_root/'src/leggedcontrol_go2/legged_controllers/config/go2/myrbf_v11_equivalent_wrench_go2.yaml']
for k in ['050','080']:
    paths.append(configs_root/('rbf_experiment_configs/myrbf_v12B_fz_bias_gain_'+k+'.yaml'))
for i,p in enumerate(paths):
    s=p.read_text(encoding='utf-8')
    x=re.search(r'(?m)^v11_leakage:\s*\n((?:-\s*[-+.0-9eE]+\s*\n){6})',s)
    assert x,'missing 6-axis leakage: '+str(p)
    vals=[float(x) for x in re.findall(r'(?m)^-\s*([-+.0-9eE]+)\s*$',x.group(1))]
    assert len(vals)==6 and all(v==0 for v in vals),f'leakage not zero: {p}: {vals}'
    wanted = (i!=0)
    assert ('v12_enable_dynamics_residual: true' in s)==wanted,str(p)
print('[OK] 43 overlay files SHA256 + Python syntax passed')
print('[OK] main + 050/080 YAML leakage all zero; main dynamics OFF; 050/080 dynamics ON')
print('[注意] 未编译 ROS/OCS2，未进行 Gazebo 仿真。')
